package com.example.myapplication.model

data class Workouts(val stringResourceId: Int)